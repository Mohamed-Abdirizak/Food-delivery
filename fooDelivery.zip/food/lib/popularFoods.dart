import 'package:flutter/material.dart';

class popularFoods extends StatelessWidget {
  final image;
  final String foodName;
  final String foodPrice;
  final String starRate;

  const popularFoods(
      {super.key,
      required this.image,
      required this.foodName,
      required this.foodPrice,
      required this.starRate});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      height: 150,
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Image.asset(
                this.image,
                height: 100,
                width: 100,
              ),
              SizedBox(
                width: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 40.0),
                child: Column(
                  // mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      this.foodName,
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Text(
                          '\$ ' + this.foodPrice,
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Icon(
                          Icons.star,
                          size: 30,
                          color: Colors.orange,
                        ),
                        Text(
                          this.starRate,
                          style: TextStyle(
                            fontSize: 20,
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ],
          ),
          Icon(
            Icons.favorite_border_outlined,
            size: 40,
            color: Colors.grey.shade300,
          ),
        ],
      ),
    );
  }
}
