import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:food/foods.dart';

class showDetailedFood extends StatelessWidget {
  final foodImage;
  final String foodRating;
  final String foodTitle;
  final ing1Image;
  final String ing1Text;
  final ing2Image;
  final String ing2Text;
  final ing3Image;
  final String ing3Text;
  final ing4Image;
  final String ing4Text;
  final String descriptionText;
  final hoosBg;
  final hoosPrice;
  const showDetailedFood({
    super.key,
    required this.foodImage,
    required this.foodRating,
    required this.foodTitle,
    required this.ing1Image,
    required this.ing1Text,
    required this.ing2Image,
    required this.ing2Text,
    required this.ing3Image,
    required this.ing3Text,
    required this.ing4Image,
    required this.ing4Text,
    required this.descriptionText,
    required this.hoosBg,
    required this.hoosPrice,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      // appBar: AppBar(title: Text("welcome to new screen...")),

      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50.0, left: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Icon(
                        Icons.arrow_back,
                        size: 45,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20.0),
                        child: Icon(
                          Icons.favorite_outline,
                          size: 40,
                        ),
                        // Text("hey")
                      )
                    ],
                  ),
                  //// line one ended here...

                  Row(
                    //////////// this row container the clicked food image and the chine text images.
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20.0),
                        child: Image.asset(
                          this.foodImage,
                          // "lib/images/sushi.png",
                          height: 350,
                          width: 300,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 90.0, right: 30),
                        //// the chinese text column.....
                        child: Column(
                          children: [
                            Image.asset(
                              "lib/images/snake.png",
                              // height: 00,
                              width: 100,
                            ),
                            Image.asset(
                              "lib/images/tiger.png",
                              // height: 00,
                              width: 100,
                            ),
                            Image.asset(
                              "lib/images/dragon.png",
                              // height: 00,
                              width: 100,
                            ),
                          ],
                        ), // the chinese text column ends here.
                      ),
                    ],
                  ), //////////// this row ends here (contains the clicked food image and the chine text images)
                  Row(
                    //// start icon and rate starts here...
                    children: [
                      Icon(
                        Icons.star,
                        size: 30,
                        color: Colors.orange,
                      ),
                      Text(
                        this.foodRating,
                        // this.foodRating,
                        style: TextStyle(fontSize: 25),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),

                  /// star icon and rate ends here....

                  Row(
                    /// this row contains the Original (food name) text.
                    children: [
                      Text(
                        // "Oridinal Sush",
                        this.foodTitle,
                        style: TextStyle(
                            fontSize: 40, fontWeight: FontWeight.bold),
                      )
                    ],
                  ), //// this row ends here (the original (food name) text)
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    /// this row starts here (ingredients text).
                    children: [
                      Text(
                        "Ingeredients",
                        style: TextStyle(fontSize: 25, color: Colors.grey[600]),
                      )
                    ],
                  ),

                  /// this row ends here (ingredients tex)...
                  SizedBox(
                    height: 20,
                  ),

                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Container(
                      child: Row(
                        children: [
                          // ingredient 1

                          food(image: ing1Image, foodName: ing1Text),
                          SizedBox(
                            width: 10,
                          ),
                          food(image: ing2Image, foodName: ing2Text),
                          SizedBox(
                            width: 10,
                          ),
                          food(image: ing3Image, foodName: ing3Text),
                          SizedBox(
                            width: 10,
                          ),
                          food(image: ing4Image, foodName: ing4Text),
                          // food(
                          //     image: "lib/images/sushi.png", foodName: "sushi"),

                          SizedBox(
                            width: 10,
                          ),
                          // food(

                          //     /// ingredient 2
                          //     image: ing2Image,
                          //     foodName: ing2Text),
                          // SizedBox(
                          //   width: 10,
                          // ),
                          // food(

                          //     /// ingredient 3
                          //     image: ing3Image,
                          //     foodName: ing3Text),
                          // SizedBox(
                          //   width: 10,
                          // ),
                          // food(
                          //     // ingredient 4
                          //     image: ing4Image,
                          //     foodName: ing4Text),
                          // SizedBox(
                          //   width: 10,
                          // ),

                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Expanded(
                  //   /// this line begins here (the ingredients container text and image..)
                  //   child: ListView(
                  //     scrollDirection: Axis.horizontal,
                  //     children: [
                  //       Row(
                  //         crossAxisAlignment: CrossAxisAlignment.start,
                  //         children: [
                  //           food(
                  //               image: 'lib/images/fried-rice.png',
                  //               foodName: "Rice"),
                  //           SizedBox(
                  //             width: 10,
                  //           ),
                  //           food(image: 'lib/images/rice.png', foodName: "Rice"),
                  //           SizedBox(
                  //             width: 10,
                  //           ),
                  //           food(image: 'lib/images/rice.png', foodName: "Rice"),
                  //           SizedBox(
                  //             width: 10,
                  //           ),
                  //           food(image: 'lib/images/rice.png', foodName: "Rice"),
                  //         ],
                  //       ),
                  //     ],
                  //   ),
                  // ),

                  /// this line ends here (the ingredients container text and image..)
                  ///
                  /// szi
                  SizedBox(
                    height: 30,
                  ),

                  //// this starsts the description text and its contents////
                  Padding(
                    padding: const EdgeInsets.all(.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      // mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          "Description",
                          style: TextStyle(fontSize: 20, color: Colors.black54),
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Text(
                          this.descriptionText,
                          // "Sushi is typically made with rice, nori (seaweed), fish, and vegetables. Common sushi ingredients include tuna, salmon, shrimp, squid, eel, and crab. You can use almost any ingredient you like in sushi. Popular ingredients include.",
                          style:
                              TextStyle(fontSize: 18, color: Colors.grey[600]),
                        )
                      ],
                    ),
                  ), //// this ends here, the description text and its contents////

                  // Container(
                  //   decoration: BoxDecoration(
                  //       color: Colors.orange,
                  //       borderRadius: BorderRadius.only(
                  //           bottomRight: Radius.circular(12),
                  //           bottomLeft: Radius.circular(12))),
                  //   padding: EdgeInsets.all(9),
                  //   height: 200,
                  //   width: MediaQuery.of(context).size.width,
                  //   // color: Colors.amber,
                  //   child: Column(
                  //     children: [],
                  //   ),
                  // )
                ],
              ),
            ),
            SizedBox(
              height: 15,
            ),

            //// qeeybta hoose starts here (the orange container and its content...)
            Container(
              decoration: BoxDecoration(
                  // color: hoosBg,
                  color: hoosBg,
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(30),
                      bottomLeft: Radius.circular(30))),
              padding: EdgeInsets.all(9),
              height: 200,
              width: MediaQuery.of(context).size.width,
              // color: Colors.amber,
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(30.0),
                    child: Row(
                      // this row starts here: the main row ay ku hoosjiraan: price + 2 -
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "\$" + hoosPrice,
                          // "\$40",
                          style: TextStyle(fontSize: 30, color: Colors.white),
                        ),
                        Row(
                          //this row stars here rowgaani wuxuu qeeb gooni ah kadhigaa + 2 -..
                          children: [
                            Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                    color: Colors.white24,
                                    borderRadius: BorderRadius.circular(30)),
                                child: Icon(
                                  Icons.remove,
                                  color: Colors.white,
                                  size: 30,
                                )),
                            SizedBox(
                              width: 20,
                            ),
                            Text(
                              "2",
                              style:
                                  TextStyle(fontSize: 30, color: Colors.white),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                            Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                    color: Colors.white24,
                                    borderRadius: BorderRadius.circular(30)),
                                child: Icon(
                                  Icons.add,
                                  color: Colors.white,
                                  size: 30,
                                )),
                          ],
                        ), //this row ends here rowgaani wuxuu qeeb gooni ah kadhigaa + 2 -..
                      ],
                    ), // this row ends here: the main row ay ku hoosjiraan: price + 2 -
                  ),
                  Container(
                    padding: EdgeInsets.only(
                        top: 20, right: 20, bottom: 20, left: 200),
                    decoration: BoxDecoration(
                        color: Colors.white24,
                        borderRadius: BorderRadius.circular(30)),
                    child: Row(children: [
                      Text(
                        "Buy Now",
                        style: TextStyle(fontSize: 20, color: Colors.white),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Icon(
                        Icons.arrow_forward,
                        size: 30,
                        color: Colors.white,
                      )
                    ]),
                  )
                ],
              ),
            ), //// qeeybta hoose ends here (the orange container and its content...)
          ],
        ),
      ),
    );
  }
}
