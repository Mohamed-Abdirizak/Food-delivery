import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:food/showDetailedFood.dart';

import 'Widgets.dart';
import 'popularFoods.dart';
import 'foods.dart';

class Home extends StatelessWidget {
  // const Home({super.key});

  // void printHello() {
  //   // print("hello world");
  //   showDetailedFood();
  // }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey.shade100,
        body:
            // SafeArea(

            // child:
            ListView(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    Icons.menu,
                    size: 50,
                  ),

                  /// this row contains location icon and city name..
                  Row(
                    children: [
                      Icon(
                        Icons.location_on_outlined,
                        size: 30,
                        color: Colors.red,
                      ),
                      Text(
                        "Muqdisho",
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w500),
                      )
                    ],
                  ),

                  /// lcoaiton row and city name ends here....
                  Icon(
                    Icons.person,
                    size: 50,
                    color: Colors.red,
                  ),
                ],
              ),
            ),

            /// the first row ends here....
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.red[400],
                    borderRadius: BorderRadius.circular(50)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(30.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Get 32% Promo",
                            style: TextStyle(fontSize: 30, color: Colors.white),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Container(
                              padding: EdgeInsets.only(
                                  left: 30, right: 30, top: 10, bottom: 10),
                              decoration: BoxDecoration(
                                  color: Colors.white60,
                                  borderRadius: BorderRadius.circular(12)),
                              child: Text(
                                "Buy Food",
                                style: TextStyle(
                                    fontSize: 30, color: Colors.white),
                              )),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Image.asset(
                        "lib/images/pasta.png",
                        fit: BoxFit.cover,
                        height: 200,
                        width: 200,
                      ),
                    )
                  ],
                ),
              ),
            ),

            //// third line begins here..... container ...
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                  padding: EdgeInsets.all(25),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12)),
                  child: TextField(
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.search),
                        hintText: 'Search here...'),
                  )),
            ),
            /////////// the third line ends here....... serach fake ah oo container iyo text iyo icon loo isticmaale.

            Padding(
              padding: const EdgeInsets.all(20.0),
              // child: Container(
              // decoration: BoxDecoration(color: Colors.grey[100]),
              // padding: EdgeInsets.all(10),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  margin: EdgeInsets.only(right: 20),
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      food(image: "lib/images/sushi.png", foodName: "Sushi"),
                      SizedBox(
                        width: 20,
                      ),
                      food(image: "lib/images/rice.png", foodName: "Rice"),
                      SizedBox(
                        width: 20,
                      ),
                      food(image: "lib/images/sushi.png", foodName: "Sushi"),
                    ],
                  ),
                ),
              ),

              // ),/
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Container(
                padding: EdgeInsets.only(right: 20),
                child: Row(
                  children: [
                    /// food 1..
                    Sushi(
                        og: 'Original Sushi',
                        star: '4.6',
                        money: '\$2.00',
                        img: "lib/images/nigiri.png",
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => showDetailedFood(
                                      foodImage: "lib/images/sushi.png",
                                      foodRating: "4.6",
                                      foodTitle: "Original Sushi",
                                      ing1Image: "lib/images/eel.png",
                                      ing1Text: "Eel",
                                      ing2Image: "lib/images/shrimp.png",
                                      ing2Text: "Shrimp",
                                      ing3Image: "lib/images/fish.png",
                                      ing3Text: "Fish",
                                      ing4Image: "lib/images/friedEgg.png",
                                      ing4Text: "Fried Egg",
                                      descriptionText:
                                          "Sushi is typically made with rice, nori (seaweed), fish, and vegetables. Common sushi ingredients include tuna, salmon, shrimp, squid, eel, and crab. You can use almost any ingredient you like in sushi. Popular ingredients include.",
                                      hoosBg: Colors.orange,
                                      hoosPrice: "4.00")));
                        }),

                    /// food 1 ends here..
                    ///// food 2 starts here.
                    Sushi(
                        og: 'Original Hamburger',
                        star: '4.3',
                        money: '\$7.00',
                        img: "lib/images/hamburger.png",
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => showDetailedFood(
                                      foodImage: "lib/images/hamburger.png",
                                      foodRating: "4.3",
                                      foodTitle: "Original Hamburger",
                                      ing1Image: "lib/images/meat.png",
                                      ing1Text: "Meat",
                                      ing2Image: "lib/images/crisps.png",
                                      ing2Text: "Crisps",
                                      ing3Image: "lib/images/hot-sauce.png",
                                      ing3Text: "Hot Sauce",
                                      ing4Image: "lib/images/bread.png",
                                      ing4Text: "Fried bread",
                                      descriptionText:
                                          "Hamburger is typically made with meat, crisps, bread and vegetables. Common sushi ingredients include meat, hot sauce, bread, squid, eel, and crab. You can use almost any ingredient you like in sushi. Popular ingredients include.",
                                      hoosBg: Colors.orange,
                                      hoosPrice: "14.00")));
                        }),
                    ///////  food 3 starts here...
                    Sushi(
                        og: 'Original Pizza',
                        star: '4.8',
                        money: '\$25.00',
                        img: "lib/images/pizza.png",
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => showDetailedFood(
                                      foodImage: "lib/images/pizza.png",
                                      foodRating: "4.8",
                                      foodTitle: "Original Pizza",
                                      ing1Image: "lib/images/cheese.png",
                                      ing1Text: "Cheese",
                                      ing2Image: "lib/images/mozzarella.png",
                                      ing2Text: "mozzarella",
                                      ing3Image: "lib/images/hot-sauce.png",
                                      ing3Text: "Hot Sauce",
                                      ing4Image: "lib/images/capsicum.png",
                                      ing4Text: "Capsicum",
                                      descriptionText:
                                          "Pizza is typically made with cheeze, hot-sauce, bread and vegetables. Common sushi ingredients include cheese, hot sauce, bread, squid, eel, and crab. You can use almost any ingredient you like in sushi. Popular ingredients include.",
                                      hoosBg: Colors.orange,
                                      hoosPrice: "50.00")));
                        }),
                  ],
                ),
              ),
            ),
            Container(
                margin: EdgeInsets.all(20),
                child: Text(
                  'Popular Foods',
                  style: TextStyle(fontSize: 22),
                )),
            popularFoods(
                image: "lib/images/biryani.png",
                foodName: "Biryani Rice",
                foodPrice: "5.00",
                starRate: "4.5"),

            popularFoods(
                image: "lib/images/popcorn.png",
                foodName: "Popcorn",
                foodPrice: "3.00",
                starRate: "4.4"),

            popularFoods(
                image: "lib/images/friedEgg.png",
                foodName: "Fried Egg",
                foodPrice: "1.00",
                starRate: "4.6"),

            popularFoods(
                image: "lib/images/vegetable.png",
                foodName: "Vegetables",
                foodPrice: "3.00",
                starRate: "4.2")
          ],
        ),
        // ),
      ),
    );
  }
}
