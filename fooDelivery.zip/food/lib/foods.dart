import 'package:flutter/material.dart';

class food extends StatelessWidget {
  final image;
  final String foodName;
  const food({super.key, required this.image, required this.foodName});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(36)),
      padding: EdgeInsets.only(left: 40, right: 40, top: 10, bottom: 10),
      child: Row(
        children: [
          Image.asset(
            this.image,
            height: 50,
            width: 50,
          ),
          SizedBox(
            width: 10,
          ),
          Text(
            this.foodName,
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w500,
                color: Colors.redAccent),
          )
        ],
      ),
    );
  }
}
