package com.example.food

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
